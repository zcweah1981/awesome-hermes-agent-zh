# 02-team 团队协作版

这个压缩包已经把“微信小程序助手”的团队协作版整理成一个可直接解压使用的目录。

## 解压后你会看到什么
- `01-product/`：产品拆解 Agent
- `02-builder/`：小程序实现 Agent
- `03-api/`：接口设计 Agent
- `04-qa/`：测试验证 Agent
- `99-solution-validator/`：最终方案验证

## 快速安装
建议先创建 5 个独立 profile：

```bash
hermes profile create miniapp-product --clone
hermes profile create miniapp-builder --clone
hermes profile create miniapp-api --clone
hermes profile create miniapp-qa --clone
hermes profile create miniapp-validator --clone
```

然后执行：

```bash
bash ./install_all.sh
```

如果你想手动安装，也可以分别进入每个子目录执行 `bash ./install_to_profile.sh <profile>`。
